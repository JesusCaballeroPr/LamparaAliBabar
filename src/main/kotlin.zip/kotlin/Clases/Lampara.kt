class Lampara (){
    internal var estado:Boolean=false
    private var cambioColor:String="blanco"
    internal var cambiarIntensidad:Int=0
    private var ubicacion:String=""

    constructor(estado:Boolean,cambioColor:String,cambiarIntensidad: Int,ubicacion:String):this(){
        this.estado=estado
        this.cambioColor=cambioColor
        this.cambiarIntensidad=cambiarIntensidad
        this.ubicacion=ubicacion
    }
    fun setEstado(opcion: Int) {
        if (opcion==1){
            this.estado=true
        }else{
            this.estado=false

        }    }
    fun setCambioColor(readLine: String) {
        this.cambioColor=readLine
    }
    fun setCambiarIntensidad(readInt: Int) {
        this.cambiarIntensidad= readInt
    }
    fun setUbicacion(readLine: String){
        this.ubicacion=readLine
    }

    override fun toString(): String {
        return "La lámpara que se encuentra en $ubicacion, se encuentra ${queEstadoTiene()}" +
                "con un color $cambioColor y una intensidad $cambiarIntensidad"
    }

}
fun Lampara.queEstadoTiene():String {
    return if(estado){
        "encendida "
    }else{
        "apagada "
    }
}
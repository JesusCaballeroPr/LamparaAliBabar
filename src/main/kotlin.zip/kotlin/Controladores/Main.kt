package org.example.Controladores
import Lampara
import readInt
import readLine
import java.util.*

fun main() {
    val SCAN=Scanner(System.`in`)
    var lamparaSalon=Lampara()
    var lamparaHabitacion=Lampara()
    var dato=false
    println("Bienvenido al menú de la lámpara mágica :D")
    do {
        var posibilidadSalir=readInt("Por favor, si desea salir, pulse 0. " +
                "En caso contrario, presione cualquer número"
            ,"No es un número")
        if (posibilidadSalir==0){
            dato=true
        }
        else {
            lamparaSalon.setUbicacion(
                readLine(
                    "¿Que lámpara es la que quiere usar?", "Esa no es una ubicación válida"
                )
            )
            lamparaSalon.setEstado(
                readInt(
                    "Marque 1 si quiere encender la lámpara o 0 si quiere apagarla",
                    "No es un número",
                    "Fuera del rango permitido",
                    0,
                    1
                )
            )
            lamparaSalon.setCambioColor(
                readLine(
                    "Escriba de que color quiere poner su lámpara",
                    "Eso no es un color"
                )
            )
            lamparaSalon.setCambiarIntensidad(
                readInt(
                    "¿Que intensidad quiere ponerle?\t" +
                            "Puede elegir desde el 1 hasta el 5",
                    "No es una intensidad permitida",
                    "No es un rango permitido",
                    1,5
                )
            )
            println(lamparaSalon)

            lamparaHabitacion.setUbicacion(readLine(
                "¿Que lámpara es la que quiere usar?", "Esa no es una ubicación válida"
            ))
            lamparaHabitacion.setEstado(
                readInt(
                    "Marque 1 si quiere encender la lámpara o 0 si quiere apagarla",
                    "No es un número",
                    "Fuera del rango permitido",
                    0,
                    1
                )
            )
            lamparaHabitacion.setCambioColor(
                readLine(
                    "Escriba de qué color quiere poner su lámpara",
                    "Eso no es un color"
                )
            )
            lamparaHabitacion.setCambiarIntensidad(
                readInt(
                    "¿Qué intensidad quiere ponerle?\t" +
                            "Puede elegir desde el 1 hasta el 5",
                    "No es una intensidad permitida",
                    "No es un rango permitido",
                    1, 5
                )
            )
            println(lamparaHabitacion)
        }

    }while (!dato)
}
